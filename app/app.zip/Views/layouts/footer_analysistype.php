<script src="<?php echo base_url();?>/public/app-assets/js/vendors.min.js"></script>
<script src="<?php echo base_url();?>/public/app-assets/vendors/ionRangeSlider/js/ion.rangeSlider.js"></script>

<script src="<?php echo base_url();?>/public/app-assets/js/plugins.js"></script>
<script src="<?php echo base_url();?>/public/app-assets/js/search.js"></script>
<script src="<?php echo base_url();?>/public/app-assets/js/custom/custom-script.js"></script>

<script src="<?php echo base_url();?>/public/app-assets/js/scripts/extra-components-range-slider.js"></script>

<!--<script src="--><?php //echo base_url();?><!--/public/app-assets/js/scripts/advance-ui-modals.js"></script>-->

<script src="<?php echo base_url();?>/public/app-assets/js/scripts/media-hover-effects.js"></script>


<script>

    $('#typeanalysis-modal').modal();

    setTimeout(function () { $('#typeanalysis-modal').modal('open'); }, 1800)

</script>


</body>
</html>