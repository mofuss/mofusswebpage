
<div class="modal modal-fixed-footer" id="support-modal">
    <div class="modal-content">
        <div class="row">
            <div class="col s12">
                <h5 class="green-text">Support</h5>
            </div>
        </div>

        <div class="row " id="main-view">
            <div class="col s12">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad adipisci alias aliquid architecto at debitis delectus dolore, esse eveniet fuga molestiae odio provident quos rem repellat sapiente unde vitae voluptatum.</p>
            </div>

        </div>





    </div>


    <div class="modal-footer">
        <button class="waves-effect btn-flat red-text modal-action modal-close">
            CLOSE
        </button>

    </div>

</div>
