<?php

namespace App\Models;

use CodeIgniter\Model;

class MapaModel extends Model
{

    protected $table = 'tabla2';
    protected $primaryKey = 'rid';
}