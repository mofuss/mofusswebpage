<?php namespace App\Controllers;

use CodeIgniter\Controller;

class Home extends BaseController
{
	public function index()
	{
//		return view('welcome_message');
//		return view('login');
        //		return view('login');
        		return view('home');
//        		return view('home_original');
//        return view('webmofuss');
	}

    public function login()
    {
        echo 'hola';
//        return view('login');
    }





}
